Welcome & Thank You!
Thank you for purchasing a VoxelNest asset!
We appreciate your support and hope you enjoy using our asset in your projects.
If you have any questions or need assistance, feel free to reach out.

Troubleshooting
Weird Texture Colors

Issue: Some textures have strange colors.

Select the affected texture in the Inspector.
Enable sRGB (Color Texture).
Want even more stunning skyboxes? Upgrade to the full version to get 15 high-quality cubemaps.

Happy creating!
VoxelNest Team